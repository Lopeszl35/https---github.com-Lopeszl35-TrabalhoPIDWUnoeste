const InterfaceAgendamentoRepository = require('../interfaces/InterfaceAgendamentoRepository');

class AgendamentoRepository extends InterfaceAgendamentoRepository {
    constructor(database) {
        super();
        this.database = database;
    }

    async criarAgendamento(agendamento, connection) {
        const sql = `
            INSERT INTO Agendamentos (Prontuario, ID_Profissional, ID_Servico, Data_Hora, Status, Observacoes)
            VALUES (?, ?, ?, ?, ?, ?)
        `;
        const params = [
            agendamento.prontuario,
            agendamento.idProfissional,
            agendamento.idServico,
            agendamento.dataHora,
            agendamento.status,
            agendamento.observacoes
        ];
        
        try {
            const [result] = await connection.query(sql, params);
            return result.insertId; // Retorna o ID do novo agendamento
        } catch (error) {
            console.error('Erro ao criar agendamento no banco de dados:', error);
            throw new Error('Erro ao criar agendamento no banco de dados');
        }
    }
}

module.exports = AgendamentoRepository;
