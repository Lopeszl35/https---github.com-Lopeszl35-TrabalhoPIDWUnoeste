class ResponsaveisModel {
    constructor(Prontuario, Nome_Mae, Telefone_Mae, Nome_Pai, Telefone_Pai) {
        this.Prontuario = Prontuario;
        this.Nome_Mae = Nome_Mae;
        this.Telefone_Mae = Telefone_Mae;
        this.Nome_Pai = Nome_Pai;
        this.Telefone_Pai = Telefone_Pai;
    }
}

module.exports = ResponsaveisModel;
