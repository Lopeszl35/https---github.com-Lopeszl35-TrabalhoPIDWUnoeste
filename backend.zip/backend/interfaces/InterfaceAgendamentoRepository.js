class InterfaceAgendamentoRepository {
    criarAgendamento(agendamento) {}
    buscarAgendamentoPorId(id) {}
    atualizarAgendamento(id, dadosAtualizados) {}
    excluirAgendamento(id) {}
    listarAgendamentos() {}
}

module.exports = InterfaceAgendamentoRepository